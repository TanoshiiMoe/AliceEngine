<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Tile_Road" tilewidth="120" tileheight="120" tilecount="15" columns="5">
 <image source="Tile_Road.png" width="600" height="360"/>
</tileset>
